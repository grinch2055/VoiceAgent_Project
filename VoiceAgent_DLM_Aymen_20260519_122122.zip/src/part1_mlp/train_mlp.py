import torch, torch.nn as nn, torch.optim as optim
from torch.utils.data import Dataset, DataLoader
from sklearn.metrics import classification_report, confusion_matrix
from sklearn.model_selection import train_test_split

class TabularDS(Dataset):
    def __init__(self, X, y):
        self.X = torch.as_tensor(X, dtype=torch.float32)
        self.y = torch.as_tensor(y, dtype=torch.long)
    def __len__(self): return len(self.y)
    def __getitem__(self, i): return self.X[i], self.y[i]

X, y = torch.load("data/raw_voice/part1.pt", weights_only=True)
X_np, y_np = X.numpy(), y.numpy()
X_train, X_test, y_train, y_test = train_test_split(X_np, y_np, test_size=0.2, stratify=y_np, random_state=42)

train_ds = TabularDS(X_train, y_train)
test_ds = TabularDS(X_test, y_test)
train_dl = DataLoader(train_ds, batch_size=32, shuffle=True)
test_dl = DataLoader(test_ds, batch_size=32)

device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
print(f"Device: {device}")

class MLP_Custom(nn.Module):
    def __init__(self):
        super().__init__()
        self.fc1 = nn.Linear(24, 64)
        self.fc2 = nn.Linear(64, 32)
        self.out = nn.Linear(32, 4)
    def forward(self, x):
        return self.out(torch.relu(self.fc2(torch.relu(self.fc1(x)))))

def create_sequential_mlp():
    return nn.Sequential(nn.Linear(24,64), nn.ReLU(), nn.Linear(64,32), nn.ReLU(), nn.Linear(32,4))

def test_init(model_factory, name):
    for init_name, init_fn in [("Xavier", nn.init.xavier_uniform_), ("Gaussian", lambda t: nn.init.normal_(t, std=0.01)), ("Constant", lambda t: nn.init.constant_(t, 0.5))]:
        m = model_factory().to(device)
        m.apply(lambda mod: init_fn(mod.weight) if hasattr(mod, "weight") else None)
        opt = optim.Adam(m.parameters(), lr=1e-3)
        for ep in range(20):
            for xb, yb in train_dl:
                xb, yb = xb.to(device), yb.to(device)
                opt.zero_grad()
                loss = nn.CrossEntropyLoss()(m(xb), yb)
                loss.backward()
                opt.step()
        torch.save(m.state_dict(), f"mlp_{name}_{init_name}.pth")
        print(f"  {name} + {init_name} saved.")

test_init(MLP_Custom, "Custom")
test_init(create_sequential_mlp, "Sequential")

best = MLP_Custom().to(device)
best.load_state_dict(torch.load("mlp_Custom_Xavier.pth", weights_only=True))
best.eval()
y_true, y_pred = [], []
with torch.no_grad():
    for xb, yb in test_dl:
        y_true.extend(yb.tolist())
        y_pred.extend(best(xb.to(device)).argmax(1).tolist())

print("\n? Classification Report:")
print(classification_report(y_true, y_pred, zero_division=0, labels=[0,1,2,3]))
print("Confusion Matrix:")
cm = confusion_matrix(y_true, y_pred, labels=[0,1,2,3])
print(cm)
torch.save(best.state_dict(), "mlp_best.pth")
print("? Part I complete. Models saved.")
