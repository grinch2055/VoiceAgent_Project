# -*- coding: utf-8 -*-
import torch
import torch.nn as nn
import torch.optim as optim
from torch.utils.data import DataLoader, TensorDataset

# Load placeholder sequence data
src, tgt = torch.load("data/raw_voice/part3.pt", weights_only=True)
ds = TensorDataset(src, tgt)
dl = DataLoader(ds, batch_size=16, shuffle=True)
device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
print(f"Device: {device}")

class EncoderGRU(nn.Module):
    def __init__(self, vocab_size, embed_dim, hidden_dim):
        super().__init__()
        self.embedding = nn.Embedding(vocab_size, embed_dim)
        self.gru = nn.GRU(embed_dim, hidden_dim, batch_first=True)
    def forward(self, x):
        embedded = self.embedding(x)
        outputs, hidden = self.gru(embedded)
        return outputs, hidden

class DecoderGRU(nn.Module):
    def __init__(self, vocab_size, embed_dim, hidden_dim, output_size):
        super().__init__()
        self.embedding = nn.Embedding(vocab_size, embed_dim)
        self.gru = nn.GRU(embed_dim, hidden_dim, batch_first=True)
        self.fc = nn.Linear(hidden_dim, output_size)
    def forward(self, x, hidden):
        # x shape: (batch, 1)
        embedded = self.embedding(x)  # -> (batch, 1, embed_dim)
        output, hidden = self.gru(embedded, hidden)  # -> (batch, 1, hidden)
        logits = self.fc(output.squeeze(1))  # -> (batch, vocab)
        return logits, hidden

class Seq2Seq(nn.Module):
    def __init__(self, src_vocab, tgt_vocab, embed_dim, hidden_dim):
        super().__init__()
        self.tgt_vocab = tgt_vocab
        self.enc = EncoderGRU(src_vocab, embed_dim, hidden_dim)
        self.dec = DecoderGRU(tgt_vocab, embed_dim, hidden_dim, tgt_vocab)
        self.loss_fn = nn.CrossEntropyLoss(ignore_index=0)

    def forward(self, src, tgt, teacher_forcing_ratio=0.5):
        batch_size = src.shape[0]
        tgt_len = tgt.shape[1]
        _, enc_hidden = self.enc(src)
        dec_input = tgt[:, 0].unsqueeze(1)  # (batch, 1)
        dec_hidden = enc_hidden
        logits = torch.zeros(batch_size, tgt_len, self.tgt_vocab, device=src.device)

        for t in range(1, tgt_len):
            output, dec_hidden = self.dec(dec_input, dec_hidden)
            logits[:, t] = output
            if torch.rand(1).item() < teacher_forcing_ratio:
                dec_input = tgt[:, t].unsqueeze(1)
            else:
                dec_input = output.argmax(dim=1, keepdim=True)
        return logits

    def greedy_decode(self, src, max_len=10):
        batch_size = src.shape[0]
        _, enc_hidden = self.enc(src)
        dec_input = torch.ones(batch_size, 1, dtype=torch.long, device=src.device)
        outputs = []
        for _ in range(max_len):
            pred, enc_hidden = self.dec(dec_input, enc_hidden)
            pred = pred.argmax(dim=1, keepdim=True)
            outputs.append(pred.squeeze(1))
            dec_input = pred
        return torch.stack(outputs, dim=1)

    def beam_decode(self, src, beam_width=3, max_len=10):
        _, enc_hidden = self.enc(src)
        # Initialize with <bos> token: shape (1, 1)
        beams = [(torch.ones(1, 1, dtype=torch.long, device=src.device), 0.0, enc_hidden)]
        for step in range(max_len):
            candidates = []
            for seq, score, hidden in beams:
                if seq[0, -1] == 2:  # <eos>
                    candidates.append((seq, score, hidden))
                    continue
                # FIX: seq[:, -1:] is already (1, 1). No extra unsqueeze.
                dec_input = seq[:, -1:]
                output, new_hidden = self.dec(dec_input, hidden)
                log_probs = torch.log_softmax(output, dim=1)
                topk = log_probs.topk(beam_width)
                for log_p, token_idx in zip(topk.values[0], topk.indices[0]):
                    new_seq = torch.cat([seq, token_idx.unsqueeze(0).unsqueeze(0)], dim=1)
                    candidates.append((new_seq, score + log_p.item(), new_hidden))
            beams = sorted(candidates, key=lambda x: x[1] / (x[0].shape[1] ** 0.5), reverse=True)[:beam_width]
        return beams[0][0].squeeze(0)

# Initialize & Train
model = Seq2Seq(src_vocab=50, tgt_vocab=10, embed_dim=32, hidden_dim=64).to(device)
optimizer = optim.Adam(model.parameters(), lr=1e-3)
epochs = 20

for epoch in range(epochs):
    model.train()
    total_loss = 0.0
    for src_batch, tgt_batch in dl:
        src_batch, tgt_batch = src_batch.to(device), tgt_batch.to(device)
        optimizer.zero_grad()
        logits = model(src_batch, tgt_batch, teacher_forcing_ratio=0.7)
        loss = model.loss_fn(logits[:, 1:].reshape(-1, model.tgt_vocab), tgt_batch[:, 1:].reshape(-1))
        loss.backward()
        torch.nn.utils.clip_grad_norm_(model.parameters(), max_norm=1.0)
        optimizer.step()
        total_loss += loss.item()
    print(f"Epoch {epoch+1}/{epochs} | Avg loss: {total_loss/len(dl):.4f}")

# Decode Demo
model.eval()
src_sample = torch.randint(1, 50, (1, 15), device=device)
tgt_sample = torch.randint(1, 10, (1, 8), device=device)

with torch.no_grad():
    greedy_out = model.greedy_decode(src_sample, max_len=10)
    beam_out = model.beam_decode(src_sample, beam_width=3, max_len=10)
    print(f"\nSample decoding:")
    print(f"  Greedy: {greedy_out.squeeze().tolist()}")
    print(f"  Beam(k=3): {beam_out.tolist()}")
    print(f"  Reference: {tgt_sample.squeeze().tolist()}")

torch.save(model.state_dict(), "seq2seq_gru.pth")
print("\nPart III complete. Seq2Seq model with BPTT, teacher forcing, and beam search saved.")
