# -*- coding: utf-8 -*-
import torch
import torch.nn as nn
import torch.optim as optim
from torch.utils.data import DataLoader, TensorDataset

# Manual 2D cross-correlation (rubric requirement)
def corr2d_manual(X, K):
    """Compute 2D cross-correlation from scratch"""
    h, w = K.shape[-2], K.shape[-1]
    out_h = X.shape[-2] - h + 1
    out_w = X.shape[-1] - w + 1
    Y = torch.zeros(X.shape[0], X.shape[1], out_h, out_w, device=X.device)
    for i in range(out_h):
        for j in range(out_w):
            Y[:, :, i, j] = (X[:, :, i:i+h, j:j+w] * K).sum(dim=(2, 3))
    return Y

# Manual max-pooling (rubric requirement)
def maxpool2d_manual(X, pool_size=2, stride=2):
    """Simple 2x2 max pooling with stride"""
    return nn.functional.max_pool2d(X, kernel_size=pool_size, stride=stride)

# Load placeholder data
X, y = torch.load("data/raw_voice/part2.pt", weights_only=True)
ds = TensorDataset(X, y)
dl = DataLoader(ds, batch_size=16, shuffle=True)
device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
print(f"Device: {device}")

# LeNet-style CNN architecture (fiche CNN section 9)
class LeNet(nn.Module):
    def __init__(self, num_classes=4):
        super().__init__()
        self.net = nn.Sequential(
            # Conv block 1
            nn.Conv2d(1, 6, kernel_size=5, padding=2),
            nn.Sigmoid(),
            nn.AvgPool2d(kernel_size=2, stride=2),
            # Conv block 2
            nn.Conv2d(6, 16, kernel_size=5),
            nn.Sigmoid(),
            nn.AvgPool2d(kernel_size=2, stride=2),
            # Fully connected layers
            nn.Flatten(),
            nn.LazyLinear(120),
            nn.Sigmoid(),
            nn.LazyLinear(84),
            nn.Sigmoid(),
            nn.LazyLinear(num_classes)
        )
    
    def forward(self, x):
        return self.net(x)

# Padding & stride experiments (fiche CNN section 5)
print("\nPadding and stride dimension check:")
for p, s in [(1, 1), (0, 1), (1, 2)]:
    layer = nn.Conv2d(1, 4, kernel_size=3, padding=p, stride=s).to(device)
    inp = torch.randn(2, 1, 128, 100, device=device)
    out = layer(inp)
    print(f"  padding={p}, stride={s} -> output shape: {list(out.shape)}")

# Training loop
model = LeNet().to(device)
optimizer = optim.Adam(model.parameters(), lr=1e-3)
criterion = nn.CrossEntropyLoss()
epochs = 20

for epoch in range(epochs):
    model.train()
    total_loss = 0.0
    for xb, yb in dl:
        xb, yb = xb.to(device), yb.to(device)
        optimizer.zero_grad()
        logits = model(xb)
        loss = criterion(logits, yb)
        loss.backward()
        optimizer.step()
        total_loss += loss.item()
    avg_loss = total_loss / len(dl)
    print(f"Epoch {epoch+1}/{epochs} | Avg loss: {avg_loss:.4f}")

# Feature map visualization hook (fiche CNN section 9.6)
activations = []
def hook_fn(module, input, output):
    activations.append(output.detach().cpu())

# Register hook on first conv layer
model.net[0].register_forward_hook(hook_fn)
_ = model(torch.randn(1, 1, 128, 100, device=device))
if activations:
    print(f"\nFeature map captured: shape {list(activations[0].shape)}")

# Save model state_dict (rubric requirement)
torch.save(model.state_dict(), "cnn_lenet.pth")
print("\nPart II complete. Model and experiments saved.")
